<style>
        body{
            margin-top: 100px;
            background-color: rgb(156, 215, 175);
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            
        }
        .container{
            display: flex;
            justify-content: space-evenly;
            flex-wrap: wrap;
        }
    </style>
</head>
<body>

    <?php
        
         session_start();
         $user=$_SESSION["username"];
         $con = mysqli_connect("localhost","root","","K_petcare"); 
     
     
         if (isset($_POST["enter"])) {

             $sql="INSERT INTO `reviews` VALUES('".$_POST['comment']."','".$_SESSION['username']."')";
             $result=$con->query($sql);
    
         }
    
    ?>
    <center>
        <h1>feedback</h1>
    <form action="" method="post">
        comment: <input type="text" name="comment" id="" placeholder="enter comment">
        <input type="submit" name="enter">
    </form>

    <br>
    <h1>other reviews</h1>
    <?php
    $sql="SELECT * FROM reviews";
    $result=$con->query($sql);
    echo '<center>';
    echo '<br><br>';
    if (mysqli_num_rows($result)>0) {
        while ($boarding=mysqli_fetch_array($result)) {
        echo '<div class="bookings">';
         echo 'user : '.$boarding['enter_reviews'].'<br>';
         echo 'comment : '.$boarding['user'].'<br>';
         echo '</div>';
         echo '<br><br>';
        }
    }
    
    ?>




    </center>
</body>
</html>