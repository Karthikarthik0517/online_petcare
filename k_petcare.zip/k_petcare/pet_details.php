<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Library Management System</title>
    </head>
    <style>
.center {
  text-align: center;
  background: grey;
  
}
</style>
    
    <body>
        
        <form  action="" method="post" >
            <div class="center">
            <h1>pet_details</h1>
            <label>pet_name</label></br><input type="text"   name="pet_name"><br/> 
            <label>pet_type</label></br><input type="text"   name="pet_type"><br/> 
            <label>age</label></br><input type="text"   name="age"><br/> 
            <label>sex</label></br><input type="text"   name="sex"><br/></br>
            <label>medical_issues</label></br><input type="text"   name="medical_issuses"><br/></br>
            <button "submit"  name="submit" value="pet_details" >submit</button>
            <br>
            
            </div>
        </form>
        
        
        <?php
        session_start();
        // put your code here
        $pet_name = $pet_type = $age = $sex = $medical_issues="" ;
        
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $pet_name= $_POST['pet_name'];
            $pet_type= $_POST['pet_type'];
            $age = $_POST['age'];
            $sex = $_POST['sex'];
            $medical_issues =$_POST['medical_issuses'];
            $user=$_SESSION['username'];
            
            $con = mysqli_connect("localhost","root","","k_petcare");                     
       
			$query = "INSERT INTO `pet_details` (pet_name,pet_type, age, sex, medical_issues,user) VALUES ('$pet_name', '$pet_type', '$age', '$sex', '$medical_issues','$user')";
                        $result = mysqli_query($con,$query);
                        if($result){
			 header('Location:usrhome.html');
			            }
                                    else
                                    {
                                        echo ("Fail"); 
                                    }
                         } 
        
        
        
        ?>
    </body>
</html>
