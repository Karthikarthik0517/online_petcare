<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Library Management System</title>
    </head>
    <style>
.center {
  text-align: center;
  background: plum;
  
}
</style>
    
    <body>
        
        <form  action="" method="post" >
            <div class="center">
            <h1>pooling</h1>
            <label>date</label></br><input type="date"   name="date"><br/> 
            <label>time</label></br><input type="time"   name="time"><br/> 
            <label>water_type</label></br><input type="text"   name="water_type"><br/> 
            <button "book"  name="book" value="grooming" >book</button>
            <br> 
            
            </div>
        </form>
        
        
        <?php
        session_start();
        // put your code here
        $date = $time =$water_type= "" ;
        
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $date = $_POST['date'];
            $time=$_POST['time'];
            $water_type=$_POST['water_type'];
            $user=$_SESSION['username'];
            
            $con = mysqli_connect("localhost","root","","k_petcare");                     
       
			$query = "INSERT INTO `pooling` (date,time,water_type,user) VALUES ('$date', '$time','$water_type','$user')";
                        $result = mysqli_query($con,$query);
                        if($result){
			 echo ("booking Succesfull");
			            }
                                    else
                                    {
                                        echo ("Fail"); 
                                    }
                         } 
        
        
        
        ?>
                <button onclick="window.location='usrhome.html'">Home</button>
    </body>
</html>

