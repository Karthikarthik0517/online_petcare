<!DOCTYPE html>
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Library Management System</title>
    </head>
    <style>
.center {
  text-align: center;
  background: blanchedalmond;
  
}
</style>
    
    <body>
        
        <form  action="" method="post" >
            <div class="center">
            <h1>boarding </h1>
            <label>start_date</label></br><input type="date"   name="start_date"><br/> 
            <label>end_date</label></br><input type="date"   name="end_date"><br/> 

            <button type="submit" name="book" value="boarding" >book</button>
            <br> 
            
            </div>
        </form>
        
        
        <?php
        session_start();
        // put your code here
        $start_date = $end_date = "" ;
        
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $start_date = $_POST['start_date'];
            $end_date=$_POST['end_date'];
            
            $con = mysqli_connect("localhost","root","","k_petcare");                     
       
			$query = "INSERT INTO `boarding` (start_date,end_date,user) VALUES ('".$start_date."', '".$end_date."','".$_SESSION['username']."')";
                        $result = mysqli_query($con,$query);
                        if($result){
			 echo ("booking Succesfull");
             
			            }
                                    else
                                    {
                                        echo ("Fail"); 
                                    }
                         } 
        ?>
        <button onclick="window.location='usrhome.html'">Home</button>
    </body>
</html>

