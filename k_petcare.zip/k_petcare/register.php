<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Library Management System</title>
    </head>
    <style>
.center {
  text-align: center;
  background: aqua;
  
}
</style>
    
    <body>
        
        <form  action="" method="post" >
            <div class="center">
            <h1>Registration </h1>
            <label>NAME</label></br><input type="text"   name="name"><br/> 
            <label>e-mail</label></br><input type="text"   name="e_mail"><br/> 
            <label>phone number</label></br><input type="text"   name="phone_number"><br/> 
            <label>passward</label></br><input type="text"   name="password"><br/></br>
            <label>address</label></br><input type="text"   name="address"><br/></br>
            <label>user id</label></br><input type="text"   name="user_id"><br/></br>
            <button "submit"  name="submit" value="Register" >submit</button>
            <br>
        Click here to <a href="index.php" title="Login"> Login 
            
            </div>
        </form>
        
        
        <?php
        // put your code here
        $Name = $id = $Contact = $Password = "" ;
        
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $name = $_POST['name'];
            $email = $_POST['e_mail'];
            $phno = $_POST['phone_number'];
            $Password = $_POST['password'];
            $add=$_POST['address'];
            $uid=$_POST['user_id'];
            
            $con = mysqli_connect("localhost","root","","k_petcare");                     
       
			$query = "INSERT INTO `user` (name,e_mail,phone_number,user_id,address,passward) VALUES ('$name', '$email', '$phno','$uid','$add' ,'$Password')";
                        $result = mysqli_query($con,$query);
                        if($result){
			 echo ("Registration Succesful");
			            }
                                    else
                                    {
                                        echo ("Fail"); 
                                    }
                         } 
        
        
        
        ?>
    </body>
</html>
