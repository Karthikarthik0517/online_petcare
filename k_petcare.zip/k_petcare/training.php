<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Library Management System</title>
    </head>
    <style>
.center {
  text-align: center;
  background: thistle;
  
}
</style>
    
    <body>
        
        <form  action="" method="post" >
            <div class="center">
            <h1>training</h1>
            <label>date</label></br><input type="date"   name="date"><br/>  
            <label>activity</label></br><input type="text"   name="activity"><br/>
            <label>slot</label></br><input type="time"   name="slot"><br/>  
            <button "book"  name="book" value="training" >book</button>
            <br> 
            
            </div>
        </form>
        
        
        <?php
        session_start();
        // put your code here
        $date = $time =$activity=$slot= "" ;
        
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $date = $_POST['date'];
            $activity=$_POST['activity'];
            $slot=$_POST['slot'];
            $user=$_SESSION['username'];
            
            $con = mysqli_connect("localhost","root","","k_petcare");                     
       
			$query = "INSERT INTO `training` (date,activity,slot,user) VALUES ('$date','$activity','$slot','$user')";
                        $result = mysqli_query($con,$query);
                        if($result){
			 echo ("booking Succesfull");
			            }
                                    else
                                    {
                                        echo ("Fail"); 
                                    }
                         } 
        
        
        
        ?>
                <button onclick="window.location='usrhome.html'">Home</button>
    </body>
</html>

