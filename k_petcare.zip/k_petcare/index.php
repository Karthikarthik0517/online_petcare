<!DOCTYPE html>
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <style>
            #loginform{
            text-align: center;
            
            margin: auto;
            width: 330px;
            height: 200px;
            background-color:lemonchiffon;
          
            margin-top: 100px;
            margin-bottom: 100px;
            border-radius: 10px;
            
            }  
           

     
        </style>
    </head>

    <body>
        <div id="loginform">
            
            <form method="post" action="">
                <h1>login</h1>
                <label for="username">user id : </label>
                
                <input id="username" type="text" name="name" placeholder="enter your username"><br><br>
                <label for="password">password : </label>
                <input id="password" type="password" name="password" placeholder="enter your password"><br><br>
                <input type="submit" name="submit" value="login">
               
            </form>
            
        </div>
        
        
    <?php
        // put your code here
        if(isset($_POST['submit'])){
        $name = $_POST['name'];	
       
        $password = $_POST['password'];
        
        
        $con = mysqli_connect("localhost","root","","k_petcare");
        
        if (mysqli_connect_errno())
                    {
                    echo "Failed to connect to MySQL: " .mysqli_connect_error();
                    }
		
		
			$query = "SELECT * FROM user WHERE user_id='$name' and passward='$password'";
                        $result = mysqli_query($con,$query);
                        if($result)
                        {
                            if(mysqli_num_rows($result)>0)
                            {
                                session_start();
                                $_SESSION['username'] = $name;
                                
                                header("Location: pet_details.php");
                            }
                            else{
                                echo("Invalid credenatials");
                            }
                            
                        }                     
                        else{
                            echo("Invalid credenatials");
                        }
	      }
               
        
        
        
        
        
        ?>
    </body>
</html>
