<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            margin-top: 100px;
            background-color: rgb(156, 215, 175);
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            
        }
        .container{
            display: flex;
            justify-content: space-evenly;
            flex-wrap: wrap;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    echo '    <center>
    <h1>History of '.$_SESSION['username'].'</h1>
    <center>';

    $user=$_SESSION["username"];
    $con = mysqli_connect("localhost","root","","K_petcare"); 


    if (isset($_POST["delete_boarding"])) {
        $sql='DELETE FROM `boarding` WHERE `start_date` = "'.$_POST["delete_boarding"].'"';
        $result=$con->query($sql);

        if ($result) {
            echo '<script>alert("deleted")</script>';
        }
    }
    $sql="SELECT * FROM boarding  WHERE user= '$user'";
    $result=$con->query($sql);
    echo '<center>';
    echo '<br><br>';
    if (mysqli_num_rows($result)>0) {
        while ($boarding=mysqli_fetch_array($result)) {
        echo '<div class="bookings">';
         echo 'start_data : '.$boarding['start_date'].'<br>';
         echo 'end_date : '.$boarding['end_date'].'<br>';
         echo '<button type="submit" form = "delete_boarding" name ="delete_boarding" value="'.$boarding['start_date'].'">delete</button>';
         echo '</div>';
         echo '<br><br>';
        }
    }
    echo '<form id="delete_boarding" action="" method="post">

    </form>';
    if (isset($_POST["delete_grooming"])) {
      $sql='DELETE FROM `grooming` WHERE `date` = "'.$_POST["delete_grooming"].'"';
      $result=$con->query($sql);

      if ($result) {
          echo '<script>alert("deleted")</script>';
      }
  }
    $sql="SELECT * FROM grooming  WHERE user= '$user'";
    $result=$con->query($sql);
    echo '<center>';
    echo '<br><br>';
    if (mysqli_num_rows($result)>0) {
        while ($grooming=mysqli_fetch_array($result)) {
        echo '<div class="bookings">';
         echo 'date: '.$grooming['date'].'<br>';
         echo 'time: '.$grooming['time'].'<br>';
         echo '<button type="submit" form = "delete_grooming" name ="delete_grooming" value="'.$grooming['date'].'">delete</button>';           
         echo '</div>';
         echo '<br><br>';
        }
    }
    echo '<form id="delete_grooming" action="" method="post">
    </form>';
    if (isset($_POST["delete_pooling"])) {
        $sql='DELETE FROM `pooling` WHERE `date` = "'.$_POST["delete_pooling"].'"';
        $result=$con->query($sql);

        if ($result) {
            echo '<script>alert("deleted")</script>';
        }
    }  
      $sql="SELECT * FROM pooling  WHERE `user`= '$user'";
      $result=$con->query($sql);
      echo '<center>';
      echo '<br><br>';
      if (mysqli_num_rows($result)>0) {
          while ($pooling=mysqli_fetch_array($result)) {
          echo '<div class="bookings">';
           echo 'date : '.$pooling['date'].'<br>';
           echo 'time : '.$pooling['time'].'<br>';
           echo 'water_type : '.$pooling['water_type'].'<br>';
           echo '<button type="submit" form = "delete_pooling" name ="delete_pooling" value="'.$pooling['date'].'">delete</button>';  
           echo '</div>';
           echo '<br><br>';
          }
      }
      echo '<form id="delete_pooling" action="" method="post">
      </form>';
     if (isset($_POST["delete_training"])) {
      $sql='DELETE FROM `training` WHERE `date` = "'.$_POST["delete_training"].'"';
      $result=$con->query($sql);

      if ($result) {
          echo '<script>alert("deleted")</script>';
      }
  }
    $sql="SELECT * FROM training WHERE user= '$user'";
    $result=$con->query($sql);
    echo '<center>';
    echo '<br><br>';
    if (mysqli_num_rows($result)>0) {
        while ($training=mysqli_fetch_array($result)) {
        echo '<div class="bookings">';
         echo 'date: '.$training['date'].'<br>';
         echo 'slot : '.$training['slot'].'<br>';
         echo 'activity: '.$training['activity'].'<br>';
         echo '<button type="submit" form = "delete_training" name ="delete_training" value="'.$training['date'].'">delete</button>';  
         echo '</div>';
         echo '<br><br>';
        }
    }
    echo '<form id="delete_training" action="" method="post">
    </form>';
    echo '</center>';
    ?>

</body>




