<?php
    require('dbcon.php');
    session_start();
    if(isset($_POST['submit'])){
        $sql="SELECT * FROM user WHERE user_name='".$_POST['user_name']."' AND password='".$_POST['password']."';";
        $result=$conn->query($sql);
            if(mysqli_num_rows($result)>0){
                $_SESSION['user']=$_POST['user_name'];
                echo "<script>
				alert('login successfull');
				window.location.href='usrhome.php';
				</script>";
            }
            else {
                echo "<script>
				alert('Registration failed');
				window.location.href='usrlog.php';
				</script>";
            }
            
        
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
            body{
            
            margin: 0px;
            height: 100vh;
            display: grid;
            justify-content: center;
            position: relative;
            background-image: url('book.jpeg');
            background-size: cover;
            background-position: center;
        }
        body::before{
            content: '';
            height: 100%;
            width: 100%;
            position: absolute;
            background-color: rgba(0, 0, 0, 0.7);
        }

        form{
            display: grid;
            width: 400px;
            justify-content: center;
            background-color: rgba(95, 158, 160, 0.503);
            padding: 10px;
            border-radius: 5px;
            z-index: 1;
        }

        .p1{
            padding: 10px;
            background-color: rgba(62, 137, 140, 0.689);
            border-radius: 5px;
            margin: 10px;
        }
         

    </style>
</head>
<body>
    
    <form action="#" method="post">
        <h1>Login page</h1>

        <div class="p1">
            <h1>login credentials</h1>
            User_Name : <input name="user_name" placeholder="User_name..." type="text"><br><br>
            Password : <input name="password" placeholder="password.." type="password"><br><br>
        </div>
        <div style="padding: 10px;">
            <input type="submit" name="submit" value="login"><br>
        </div>
    </form>
    
</body>
</html>