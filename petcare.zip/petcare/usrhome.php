<?php
session_start();
if(!isset($_SESSION['user'])){
    die('this user is not authenticated') ;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            min-height: 100vh;
            margin: 0px;
            overflow-x: hidden;
        }
    #headingimg{
        width: 100vw;
        height: 300px;
        background-image: url('cat.jpg');
        background-size: cover;
        background-position: center;
        display: grid;
        align-content: center;
        justify-content: center;
        box-shadow: 0px 5px 10px rgba(0,0,0,0.8);

    }
    #headingimg::before{
    content: '';
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    height: 300px;
    width: 100vw;  
    }
    
    #menu{
        background-color: rgba(62, 150, 160, 0.689);
        padding:2px 10px;
        margin-top: 2px;
        box-shadow: 0px 2px 10px rgba(0,0,0,0.8);
    }

    #menu button{
        padding: 7px 10px;
        margin:2px ;

    }

    #cont{
        width: 100vw;
        min-height: 400px;
        background-color: rgba(95, 158, 160, 0.503);
        box-shadow: 0px 5px 10px rgba(0,0,0,0.8);
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: center;
    }
    
    .serlist{
        width: 160px;
        height: 160px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        background-color: whitesmoke;
        margin: 20px 20px;
        position: relative;
        box-shadow: 0px 3px 10px rgba(0,0,0,0.3);
        
    }

    .serlist h1,p{
        margin: 0px;
        margin: 2px 3px;
        color: white;
        z-index: 1;
    }

    .serlist button{
        width: 100%;
        z-index: 1;
    }

    .serlist::before{
    content: '';
    text-align: center;
    background-image:linear-gradient(rgba(0,0,0,0),rgba(0,0,0,0.9) 60%);
    position: absolute;
    top: 60px;
    height: 100px;
    width: 160px;
     
    }

    </style>
</head>
<body>
    <div id="headingimg">
        <h1 style="font-size:70px;color:white;z-index:1;" >Pet Care Centre</h1>
    </div>
    <br>
    <div id="menu">
        <button>Home</button>
        <button onclick="window.location='bookhist.php'">Bookings</button>
        <button onclick="window.location='contact.php'">Contact</button>
        <button onclick="window.location='logout.php'">logout</button>

    </div>
    <br>
    <div id="cont">
        <div class="serlist" style="background-image:url('pet.jpeg');background-size:cover;background-position:center;">
            <h1>Boarding</h1>
            <p>you can board your pet. we can take care</p>
            <button onclick="window.location = 'booking.php?ser=boarding'">book</button>
        </div>
        <div class="serlist" style="background-image:url('daycare.jpeg');background-size:cover;background-position:center;">
            <h1>Day care</h1>
            <p>you can board your pet. we can take care</p>
            <button onclick="window.location = 'booking.php?ser=daycare'">book</button>

        </div>
        <div class="serlist" style="background-image:url('walk.jpeg');background-size:cover;background-position:center;">
            <h1>Pet walk</h1>
            <p>you can board your pet. we can take care</p>
            <button onclick="window.location = 'booking.php?ser=petwalk'">book</button>
        </div>
        <div class="serlist" style="background-image:url('grooming.jpeg');background-size:cover;background-position:center;">
            <h1>Grooming</h1>
            <p>you can board your pet. we can take care</p>
            <button onclick="window.location = 'booking.php?ser=grooming'">book</button>
        </div>
        <div class="serlist" style="background-image:url('pooling.jpeg');background-size:cover;background-position:center;">
            <h1>Pooling</h1>
            <p>you can board your pet. we can take care</p>
            <button onclick="window.location = 'booking.php?ser=pooling'">book</button>
        </div>
        </div>
    </div>
    
</body>
</html>