<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
            body{
            min-height: 100vh;
            margin: 0px;
            display: grid;
            justify-content: center;
            position: relative;
            background-image: url('book.jpeg');
            background-size: cover;
            background-position: center;
        }
        body::before{
            content: '';
            height: 100%;
            width: 100%;
            position: absolute;
            background-color: rgba(0, 0, 0, 0.7);
        }

        form{
            display: grid;
            width: 400px;
            justify-content: center;
            background-color: rgba(95, 158, 160, 0.503);
            padding: 10px;
            border-radius: 5px;
            z-index: 1;
        }

        .p1{
            padding: 10px;
            background-color: rgba(62, 137, 140, 0.689);
            border-radius: 5px;
            margin: 10px;
        }
         

    </style>

</head>

<?php
    require('dbcon.php');
    session_start();
    if(!isset($_SESSION['user'])){
        die('this user is not authenticated') ;
    }
    if(!isset($_REQUEST['ser'])){
        die('cant acess this file directly') ;
    }
    if(isset($_POST['submit'])){

        $sql="SELECT * FROM bookings";
        $sql1="SELECT * FROM services WHERE service_type='".$_POST['service']."'";
        $result=$conn->query($sql);
        $result1=$conn->query($sql1);

        // $bk_id="bk00".(mysqli_num_rows($result)+1);
        $ser_id=mysqli_fetch_array($result1);
        $ser_id1=$ser_id['service_id'];

        if ($_POST['service']!='grooming' and $_POST['service']!='pooling') {

            $sdate_str = $_POST['sdate'];
            $edate_str = $_POST['edate'];
            $sdate = DateTime::createFromFormat('Y-m-d', $sdate_str);
            $edate = DateTime::createFromFormat('Y-m-d', $edate_str);
            $interval = $edate->diff($sdate);
            $days=$interval->days+1;
            $amt=intval($ser_id['price_per_unit_Rs'])*$days;
        }

        if ($_POST['service']=='boarding' and $_POST['service']=='daycare') {

            $sql1="INSERT INTO `pet_info` VALUES ('".$_POST['name']."', '".$_POST['breed']."', '".$_POST['pettype']."', '".$_POST['age']."', '".$_POST['weight']."', '".$_POST['medication']."', '".$_POST['food']."','')";
        }
        else{
            $sql1="INSERT INTO `pet_info` VALUES ('".$_POST['name']."', '".$_POST['breed']."', '".$_POST['pettype']."', '".$_POST['age']."', '".$_POST['weight']."', '', '','')";
        }
        

        if ($_POST['service']=='boarding') {

            $sql="INSERT INTO bookings VALUES ('', '".$_SESSION['user']."', '".$ser_id1."', '".$_POST['sdate']."', '".$_POST['edate']."', '','','".$amt."', current_timestamp(),'','upcoming')";
        }
        elseif ($_POST['service']=='daycare') {
            $sql="INSERT INTO bookings VALUES ('', '".$_SESSION['user']."', '".$ser_id1."','".$_POST['sdate']."', '".$_POST['edate']."', '".$_POST['ftime']."', '".$_POST['ttime']."', '".$amt."', current_timestamp(),'','upcoming')";
        }
        elseif ($_POST['service']=='petwalk') {
            $sql="INSERT INTO bookings VALUES ('', '".$_SESSION['user']."', '".$ser_id1."','".$_POST['sdate']."', '".$_POST['edate']."', '".$_POST['putime']."', '', '".$amt."', current_timestamp(),'".$_POST['dist']."','upcoming')";
        }
        elseif ($_POST['service']=='grooming') {
            $sql="INSERT INTO bookings VALUES ('', '".$_SESSION['user']."', '".$ser_id1."','".$_POST['date']."', '', '".$_POST['time']."', '', '".$ser_id['price_per_unit_Rs']."', current_timestamp(),'','upcoming')";
        }
        else {
            $sql="INSERT INTO bookings VALUES ('', '".$_SESSION['user']."', '".$ser_id1."','".$_POST['date']."', '', '".$_POST['time']."', '', '".$ser_id['price_per_unit_Rs']."', current_timestamp(),'','upcoming')";
        }


        echo '<form action="#" method="post">
            <div class="p1">
            
                <h1>Booking summary</h1>
                service : '.$_POST['service'].'<br>
                pet name:'.$_POST['name'].'<br>
                pet type:'.$_POST['pettype'].'<br>
                pet breed:'.$_POST['breed'].'<br>';

                if ($_POST['service']!='grooming' and $_POST['service']!='pooling') {
                    echo '
                    start date : '.$sdate_str.' <br>
                    end date : '.$edate_str.'  <br>
                    No. of days :'.$days.'  <br>
                    Payable Amount: '.$amt ;
                }
                else{
                    echo '
                    date : '.$_POST['date'].' <br>
                    time : '.$_POST['time'].'  <br>
                    Payable Amount: '.$ser_id['price_per_unit_Rs'] ;
                }
                echo '
                <br>
                <input type="hidden" name="sql" value="'.$sql.'">
                <input type="hidden" name="sql1" value="'.$sql1.'">
                <input type="submit" name="confirm" value="confirm">
            </div>
            </form>';

        exit();
    }

    if (isset($_POST['confirm'])) {
        if ($conn->query($_POST['sql'])!=true) {
            echo 'error';
        }
        elseif ($conn->query($_POST['sql1'])!=true) {
            echo 'error';
        }
        else {
            echo "<script>
                alert('Booking successfull');
                window.location.href='usrhome.php';
                </script>";
        }
    }
        
        
    

?>





<body>
    
    <form action="#" method="post">
    <?php
        if ($_REQUEST['ser']=='boarding') {
            echo '<h1>Boarding Bookings</h1>';
        }
        elseif ($_REQUEST['ser']=='daycare') {
            echo '<h1>Daycare Bookings</h1>';
        }
        elseif ($_REQUEST['ser']=='petwalk') {
            echo '<h1>Petwalk Bookings</h1>';
        }
        elseif ($_REQUEST['ser']=='grooming') {
            echo '<h1>Grooming Bookings</h1>';
        }
        else{
            echo '<h1>Pooling Bookings</h1>';
        }
    ?>
    <div class="p1">
            <h1>Pet info</h1>
            service : <input type="text" name="service" value="<?php echo $_REQUEST['ser'] ?>" readonly  ><br><br>
            Name : <input type="text" name="name" placeholder="Name.." required ><br><br>
            Breed : <input type="text" name="breed" placeholder="" required><br><br>
            pet type : <select name="pettype" >
                <option value="dog">Dog</option>
                <option value="cat">cat</option>
                <option value="bird">bird</option>
            </select><br><br>
            Age : <input type="number" name="age" placeholder="Number..." required><br><br>
            weight : <input type="number" name="weight" placeholder="Number..." required><br><br>
            
        </div>
        <?php
        if ($_REQUEST['ser']=='boarding') {
            echo '        <div class="p1">
            <h1>Booking details</h1>
            Start date : <input name="sdate" type="date" required><br><br>
            End date : <input name="edate"  type="date" required><br><br>
            Medication : <textarea name="medication" cols="20" rows="2" placeholder="Address.." required></textarea><br><br>
            food suggestion : <textarea name="food" cols="20" rows="2" placeholder="Address.." required></textarea><br><br>
        </div>';
        }
        elseif ($_REQUEST['ser']=='daycare') {
            echo '        <div class="p1">
            <h1>Booking details</h1>
            Start date : <input name="sdate" type="date" required><br><br>
            End date : <input name="edate"  type="date" required><br><br>
            from : <input name="ftime" type="time" required><br><br>
            to : <input name="ttime" type="time" required><br><br>
            Medication : <textarea name="medication" cols="20" rows="2" placeholder="Address.." required></textarea><br><br>
            food suggestion : <textarea name="food" cols="20" rows="2" placeholder="Address.." required></textarea><br><br>
        </div>';
        }
        elseif ($_REQUEST['ser']=='petwalk') {
            echo '<div class="p1">
            <h1>Booking details</h1>
            Start date : <input name="sdate" type="date" required><br><br>
            End date : <input name="edate"  type="date" required><br><br>
            distance : <input name="dist" type="number" placeholder="up to 3km" required><br><br>
            picup time : <input name="putime" type="time" required><br><br>
        </div>';
        }
        else{
            echo '<div class="p1">
            <h1>Booking details</h1>
            date : <input name="date" type="date" required><br><br>
            time : <input name="time"  type="time" required><br><br>
           
        </div>';
        }
    ?>

        <div style="padding: 10px;">
            <input type="submit" name="submit" value="Book" ><br>
        </div>
    </form>



</body>
</html>