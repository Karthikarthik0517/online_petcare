<?php
    require('dbcon.php');
    if(isset($_POST['submit'])){
        $sql="INSERT INTO user VALUES ('".$_POST['name']."', '".$_POST['email']."', '".$_POST['ph_no']."', '".$_POST['address']."', '".$_POST['user_name']."', '".$_POST['password']."')";
        ;
        if (!$conn->query($sql)) {
            echo 'error';
        }
        else {
            echo "<script>
				alert('Registration successfull');
				window.location.href='usrlog.php';
				</script>";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
            body{
            
            margin: 0px;
            display: grid;
            justify-content: center;
            position: relative;
            background-image: url('book.jpeg');
            background-size: cover;
            background-position: center;
        }
        body::before{
            content: '';
            height: 100%;
            width: 100%;
            position: absolute;
            background-color: rgba(0, 0, 0, 0.7);
        }

        form{
            display: grid;
            width: 400px;
            justify-content: center;
            background-color: rgba(95, 158, 160, 0.503);
            padding: 10px;
            border-radius: 5px;
            z-index: 1;
        }

        .p1{
            padding: 10px;
            background-color: rgba(62, 137, 140, 0.689);
            border-radius: 5px;
            margin: 10px;
        }
         

    </style>
</head>
<body>
    
    <form action="" method="post">
        <h1>User regstration</h1>
    <div class="p1">
            <h1>Personal info</h1>
            Name : <input type="text" name="name" placeholder="Name.." required ><br><br>
            E-Mail : <input type="email" name="email" placeholder="Email..." required><br><br>
            Contact.No : <input type="text" name="ph_no" placeholder="Number..." required><br><br>
            Address : <textarea name="address" cols="20" rows="3" placeholder="Address.." required></textarea>
        </div>
        <div class="p1">
            <h1>login credentials</h1>
            User_Name : <input name="user_name" placeholder="User_name..." type="text" required><br><br>
            Password : <input name="password" placeholder="password.." type="password" required><br><br>
        </div>
        <div style="padding: 10px;">
            <input type="submit" name="submit" value="register" ><br>
        </div>
    </form>
    
</body>
</html>